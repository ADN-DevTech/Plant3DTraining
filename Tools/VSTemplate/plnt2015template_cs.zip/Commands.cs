﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;

using Autodesk.ProcessPower.PnIDObjects;
using Autodesk.ProcessPower.Styles;
using Autodesk.ProcessPower.ProjectManager;
using Autodesk.ProcessPower.PlantInstance;
using Autodesk.ProcessPower.DataLinks;
using Autodesk.ProcessPower.P3dProjectParts;

namespace $safeprojectname$
{
    public class Commands
    {
      [CommandMethod("test$safeprojectname$")]
      public void CmdTest$safeprojectname$()
      {
      }
    }
}
